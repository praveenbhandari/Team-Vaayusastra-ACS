digi\.xbee\.packets\.base module
================================

.. automodule:: digi.xbee.packets.base
    :members:
    :inherited-members:
    :show-inheritance:
