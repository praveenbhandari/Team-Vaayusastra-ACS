digi\.xbee\.packets\.common module
==================================

.. automodule:: digi.xbee.packets.common
    :members:
    :inherited-members:
    :show-inheritance:
