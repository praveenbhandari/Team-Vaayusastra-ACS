digi\.xbee\.packets\.wifi module
================================

.. automodule:: digi.xbee.packets.wifi
    :members:
    :inherited-members:
    :show-inheritance:
