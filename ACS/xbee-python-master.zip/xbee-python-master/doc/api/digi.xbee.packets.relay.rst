digi\.xbee\.packets\.relay module
===================================

.. automodule:: digi.xbee.packets.relay
    :members:
    :inherited-members:
    :show-inheritance:
