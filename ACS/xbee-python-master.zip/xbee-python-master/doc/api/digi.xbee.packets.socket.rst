digi\.xbee\.packets\.socket module
===================================

.. automodule:: digi.xbee.packets.socket
    :members:
    :inherited-members:
    :show-inheritance:
